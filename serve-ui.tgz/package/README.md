# @goodparty/serve-ui

Reusable design system for GoodParty Serve products. Contains design tokens, Tailwind preset, CSS variables, and React components extracted from the governance orientation prototype.

## Quick Start

### 1. Add the dependency

```json
// package.json
{
  "dependencies": {
    "@goodparty/serve-ui": "file:../serve-ui"
  }
}
```

### 2. Extend your Tailwind config

```typescript
// tailwind.config.ts
import type { Config } from 'tailwindcss';
import servePreset from '@goodparty/serve-ui/tailwind-preset';

const config: Config = {
  presets: [servePreset],
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    // Include serve-ui components so Tailwind scans their classes
    './node_modules/@goodparty/serve-ui/**/*.tsx',
  ],
  // ...
};

export default config;
```

### 3. Import global styles

```typescript
// app/layout.tsx
import '@goodparty/serve-ui/globals.css';
```

### 4. Use components

```tsx
import {
  AppShell,
  Button,
  Card,
  Callout,
  HeroBanner,
  ProgressDots,
  PageContainer,
} from '@goodparty/serve-ui';

export default function Page() {
  return (
    <AppShell breadcrumbs={[{ label: 'Dashboard' }]}>
      <PageContainer>
        <HeroBanner
          title="Welcome to Serve"
          subtitle="Your governance assistant."
        />
        <Card className="mt-4">
          <Callout variant="blue">
            <p>Representative sampling is the moat.</p>
          </Callout>
        </Card>
        <Button variant="primary" fullWidth className="mt-4">
          Get Started
        </Button>
      </PageContainer>
    </AppShell>
  );
}
```

## Components

### Layout
| Component | Description |
|-----------|-------------|
| `AppShell` | Sidebar + header + breadcrumbs + scrollable content area |
| `Sidebar` | 256px nav sidebar, collapsible on mobile |
| `PageContainer` | Centered max-width wrapper (sm/md/lg/xl) |
| `HeroBanner` | Navy gradient hero with title, subtitle, eyebrow |

### Data Display
| Component | Description |
|-----------|-------------|
| `Card` | Standard bordered card (sm/md/lg padding) |
| `FeaturedCard` | 2px blue border, hover shadow, optional badge |
| `MeetingCard` | Subtle-bg card for events and status |
| `CTACard` | Blue-tinted card for action prompts |
| `Callout` | Left-border block (neutral/blue/quote/success/error) |
| `Badge` | Pill badge (blue/green/orange/purple/neutral) |
| `Tag` | Arbitrary-color status tag |

### Interactive
| Component | Description |
|-----------|-------------|
| `Button` | Pill button (primary/secondary/ghost/outline, sm/md/lg) |
| `SetupOption` | Radio-style selection card with custom circle |
| `ChoiceButton` | Quiz answer (A/B/C badge, correct/incorrect/dimmed) |
| `FeedbackBox` | Success/error feedback panel with slide-up animation |

### Form
| Component | Description |
|-----------|-------------|
| `Input` | Text input with label, error state, focus ring |
| `NumberInput` | Numeric input with min/max |

### Progress
| Component | Description |
|-----------|-------------|
| `ProgressDots` | Dot stepper (active=wide, past=faded, future=gray) |
| `ProgressBar` | Linear fill bar |
| `StepIndicator` | Horizontal pip bars |

### Navigation
| Component | Description |
|-----------|-------------|
| `Breadcrumbs` | Chevron-separated path trail |
| `BackLink` | Left chevron + text link |

### Feedback
| Component | Description |
|-----------|-------------|
| `CheckInOption` | Sentiment card (icon + title + description) |
| `TimelineStep` | Numbered circle + connector + content |
| `SafetyPhrase` | Colored callout for key phrases |

## Design Tokens

Access raw token values for programmatic use:

```typescript
import { colors, fontSize, spacing, borderRadius } from '@goodparty/serve-ui/tokens';

console.log(colors.primary);      // '#2563EB'
console.log(fontSize.base);       // '14px'
console.log(borderRadius.lg);     // '12px'
```

## CSS Variables

All tokens are also available as CSS custom properties when you import `globals.css`:

```css
.custom-element {
  color: var(--gp-blue);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-subtle);
}
```

## Framework Compatibility

Components that render links (AppShell, Sidebar, Breadcrumbs, BackLink) accept a `renderLink` prop so you can pass your framework's link component:

```tsx
import Link from 'next/link';

<AppShell
  renderLink={({ href, children, className }) => (
    <Link href={href} className={className}>{children}</Link>
  )}
/>
```

## Color Palette

| Token | Hex | Usage |
|-------|-----|-------|
| Primary Blue | `#2563EB` | CTAs, interactive elements |
| Blue Hover | `#0D3CB5` | Hover states |
| Navy | `#0B1529` | Hero backgrounds |
| Text | `#1E1F20` | Primary text |
| Text Secondary | `#70757A` | Supporting text |
| Text Muted | `#879099` | Timestamps, hints |
| Success | `#059669` | Positive states |
| Error | `#E00C30` | Error states |
| Warning | `#D97706` | Caution states |
