import { type ReactNode, type HTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

type BadgeVariant = 'blue' | 'green' | 'orange' | 'purple' | 'neutral';

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  children: ReactNode;
  /** Color variant */
  variant?: BadgeVariant;
}

const variantStyles: Record<BadgeVariant, string> = {
  blue: 'bg-gp-blue-light text-gp-blue',
  green: 'bg-gp-success-light text-gp-success',
  orange: 'bg-gp-warning-light text-[#92400E]',
  purple: 'bg-[#F5F3FF] text-[#7C3AED]',
  neutral: 'bg-gp-bg-subtle text-gp-text-secondary',
};

/**
 * Pill-shaped badge for status, categories, or labels.
 * Rounded-full with tinted background.
 */
export function Badge({
  children,
  variant = 'blue',
  className,
  ...props
}: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-block text-[11px] font-semibold rounded-full px-2 py-0.5',
        variantStyles[variant],
        className,
      )}
      {...props}
    >
      {children}
    </span>
  );
}
