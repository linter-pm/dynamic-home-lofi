import { type ReactNode, type HTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

interface CTACardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  /** Icon displayed to the left of content */
  icon?: ReactNode;
}

/**
 * Blue-tinted CTA card for next-step prompts and action items.
 * Uses blue-light background with blue-50 border.
 */
export function CTACard({
  children,
  icon,
  className,
  ...props
}: CTACardProps) {
  return (
    <div
      className={cn(
        'bg-gp-blue-light border border-gp-blue-50 rounded-card p-5 flex gap-3.5 items-start',
        className,
      )}
      {...props}
    >
      {icon && (
        <div className="flex-shrink-0 mt-0.5">{icon}</div>
      )}
      <div className="flex-1">{children}</div>
    </div>
  );
}
