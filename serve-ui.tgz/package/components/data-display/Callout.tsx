import { type ReactNode, type HTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

type CalloutVariant = 'neutral' | 'blue' | 'quote' | 'success' | 'error';

interface CalloutProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  /** Visual variant controlling left border color and background */
  variant?: CalloutVariant;
}

const variantStyles: Record<CalloutVariant, string> = {
  neutral: 'border-l-gp-text-secondary bg-gp-bg-subtle',
  blue: 'border-l-gp-blue bg-gp-bg-subtle',
  quote: 'border-l-gp-blue bg-gp-bg-subtle',
  success: 'border-l-gp-success bg-gp-success-light',
  error: 'border-l-gp-error bg-gp-error-light',
};

/**
 * Left-border callout block for context, quotes, or highlighted information.
 * 3px left border with tinted background.
 */
export function Callout({
  children,
  variant = 'neutral',
  className,
  ...props
}: CalloutProps) {
  return (
    <div
      className={cn(
        'border-l-[3px] rounded-r-lg p-3 lg:p-4',
        variantStyles[variant],
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}
