import { type ReactNode, type HTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  /** Padding size */
  padding?: 'sm' | 'md' | 'lg';
}

const paddingMap = {
  sm: 'p-3.5',
  md: 'p-5',
  lg: 'p-6',
} as const;

/**
 * Standard card container with border, rounded corners, and consistent padding.
 * The building block for most content sections.
 */
export function Card({
  children,
  padding = 'md',
  className,
  ...props
}: CardProps) {
  return (
    <div
      className={cn(
        'bg-white border border-gp-border rounded-xl',
        paddingMap[padding],
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}
