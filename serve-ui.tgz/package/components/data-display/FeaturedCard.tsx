import { type ReactNode, type HTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

interface FeaturedCardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  /** Optional label badge floating above the card (e.g. "RECOMMENDED") */
  badge?: string;
}

/**
 * Prominent card with 2px blue border, hover shadow, and optional floating badge.
 * Used for primary CTAs and highlighted content blocks.
 */
export function FeaturedCard({
  children,
  badge,
  className,
  ...props
}: FeaturedCardProps) {
  return (
    <div
      className={cn(
        'relative bg-white border-2 border-gp-blue rounded-card p-6 hover:shadow-card-hover transition-shadow',
        className,
      )}
      {...props}
    >
      {badge && (
        <div className="absolute -top-2.5 left-5 bg-gp-blue text-white text-[10px] font-bold tracking-wider px-2.5 py-0.5 rounded">
          {badge}
        </div>
      )}
      {children}
    </div>
  );
}
