import { type ReactNode, type HTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

interface MeetingCardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  /** Icon to display in the header */
  icon?: ReactNode;
  /** Small label text above the main content */
  label?: string;
}

/**
 * Subtle background card for meeting info, calendar events, or status displays.
 * Uses gp-bg-subtle background with light border.
 */
export function MeetingCard({
  children,
  icon,
  label,
  className,
  ...props
}: MeetingCardProps) {
  return (
    <div
      className={cn(
        'bg-gp-bg-subtle border border-gp-border-light rounded-xl p-4',
        className,
      )}
      {...props}
    >
      {(icon || label) && (
        <div className="flex items-center gap-2 mb-2">
          {icon}
          {label && (
            <span className="text-xs text-gp-text-muted">{label}</span>
          )}
        </div>
      )}
      {children}
    </div>
  );
}
