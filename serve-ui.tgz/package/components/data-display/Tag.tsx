import { type ReactNode, type HTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

interface TagProps extends HTMLAttributes<HTMLSpanElement> {
  children: ReactNode;
  /** Background color class (e.g. "bg-gp-success-light") */
  bgColor?: string;
  /** Text color class (e.g. "text-gp-success") */
  textColor?: string;
}

/**
 * Small status tag — similar to Badge but allows arbitrary color combinations.
 * Used for checklist items, timeline markers, and inline status.
 */
export function Tag({
  children,
  bgColor = 'bg-gp-bg-subtle',
  textColor = 'text-gp-text-secondary',
  className,
  ...props
}: TagProps) {
  return (
    <span
      className={cn(
        'inline-block text-[11px] font-semibold rounded-full px-2 py-0.5',
        bgColor,
        textColor,
        className,
      )}
      {...props}
    >
      {children}
    </span>
  );
}
