'use client';

import { type ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface CheckInOptionProps {
  /** Icon displayed in the tinted square */
  icon: ReactNode;
  /** Background color for the icon container (e.g. "bg-gp-success-light") */
  iconBg: string;
  /** Option title */
  title: string;
  /** Supporting description */
  description: string;
  /** Click handler */
  onClick: () => void;
  /** Custom className */
  className?: string;
}

/**
 * Sentiment selection card with icon, title, and description.
 * Used for check-in flows (How are you feeling? Ready / Nervous / Unsure).
 * Hover state shows blue border.
 */
export function CheckInOption({
  icon,
  iconBg,
  title,
  description,
  onClick,
  className,
}: CheckInOptionProps) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'flex items-center gap-3 p-4 rounded-xl border border-gp-border bg-white',
        'hover:border-gp-blue hover:bg-[#FAFCFF] transition-all text-left w-full',
        className,
      )}
    >
      <div
        className={cn(
          'w-10 h-10 rounded-[10px] flex items-center justify-center flex-shrink-0',
          iconBg,
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-sm font-semibold mb-0.5">{title}</p>
        <p className="text-[13px] text-gp-text-secondary">{description}</p>
      </div>
    </button>
  );
}
