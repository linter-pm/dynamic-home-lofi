import { type ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface SafetyPhraseProps {
  /** The phrase text (usually in quotes) */
  phrase: string;
  /** Explanation of when/why to use the phrase */
  detail: string;
  /** Background color class */
  bgColor?: string;
  /** Border color class */
  borderColor?: string;
  /** Phrase text color class */
  phraseColor?: string;
  /** Custom className */
  className?: string;
}

/**
 * Colored callout card for "phrases that save you" or key talking points.
 * Displays a bold phrase with supporting detail text below.
 */
export function SafetyPhrase({
  phrase,
  detail,
  bgColor = 'bg-gp-success-light',
  borderColor = 'border-gp-success-border',
  phraseColor = 'text-gp-success',
  className,
}: SafetyPhraseProps) {
  return (
    <div className={cn('border rounded-xl p-4', bgColor, borderColor, className)}>
      <p className={cn('text-[15px] font-semibold mb-1', phraseColor)}>
        {phrase}
      </p>
      <p className="text-[13px] text-gp-text leading-relaxed">
        {detail}
      </p>
    </div>
  );
}
