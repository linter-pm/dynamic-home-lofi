import { type ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface TimelineStepProps {
  /** Step number displayed in the circle */
  number: string | number;
  /** Step title */
  title: string;
  /** Step description */
  description: string;
  /** Whether to show the connector line below (false for last item) */
  showConnector?: boolean;
  /** Custom className */
  className?: string;
}

/**
 * Numbered circle + vertical connector line + content block.
 * Used for sequential timelines (meeting walkthrough, onboarding steps).
 */
export function TimelineStep({
  number,
  title,
  description,
  showConnector = true,
  className,
}: TimelineStepProps) {
  return (
    <div className={cn('flex gap-3 py-3', className)}>
      <div className="flex flex-col items-center">
        <div className="w-7 h-7 rounded-full bg-gp-blue-light flex items-center justify-center text-xs font-bold text-gp-blue">
          {number}
        </div>
        {showConnector && (
          <div className="w-0.5 flex-1 bg-gp-border-light mt-1" />
        )}
      </div>
      <div className="flex-1 pb-1">
        <p className="text-sm font-semibold mb-0.5">{title}</p>
        <p className="text-[13px] text-gp-text-secondary leading-relaxed">
          {description}
        </p>
      </div>
    </div>
  );
}
