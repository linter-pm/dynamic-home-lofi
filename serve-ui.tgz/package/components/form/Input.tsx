import { type InputHTMLAttributes, forwardRef } from 'react';
import { cn } from '../../lib/utils';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  /** Label text displayed above the input */
  label?: string;
  /** Error message displayed below the input */
  error?: string;
}

/**
 * Text input with focus ring, label, and error state.
 * Border-radius 8px, blue focus ring matching the design system.
 */
export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, className, id, ...props }, ref) => {
    const inputId = id ?? label?.toLowerCase().replace(/\s+/g, '-');

    return (
      <div className="w-full">
        {label && (
          <label
            htmlFor={inputId}
            className="block text-sm font-medium text-gp-text mb-1.5"
          >
            {label}
          </label>
        )}
        <input
          ref={ref}
          id={inputId}
          className={cn(
            'w-full border border-gp-border rounded-lg px-3 py-2.5 text-sm text-gp-text placeholder:text-gp-text-muted',
            'focus:outline-none focus:ring-2 focus:ring-gp-blue/20 focus:border-gp-blue',
            'transition-colors',
            error && 'border-gp-error focus:ring-gp-error/20 focus:border-gp-error',
            className,
          )}
          aria-invalid={error ? 'true' : undefined}
          aria-describedby={error ? `${inputId}-error` : undefined}
          {...props}
        />
        {error && (
          <p id={`${inputId}-error`} className="text-xs text-gp-error mt-1">
            {error}
          </p>
        )}
      </div>
    );
  },
);

Input.displayName = 'Input';
