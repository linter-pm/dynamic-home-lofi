import { type ReactNode, type ButtonHTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'outline';
type ButtonSize = 'sm' | 'md' | 'lg';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  /** Visual variant */
  variant?: ButtonVariant;
  /** Button size */
  size?: ButtonSize;
  /** Full-width button */
  fullWidth?: boolean;
  /** Icon to show before the label */
  iconLeft?: ReactNode;
  /** Icon to show after the label */
  iconRight?: ReactNode;
}

const variantStyles: Record<ButtonVariant, string> = {
  primary: 'bg-gp-blue text-white hover:bg-gp-blue-deep disabled:bg-gray-400',
  secondary: 'bg-white border border-gp-border text-gp-text hover:bg-gp-bg-subtle',
  ghost: 'text-gp-text-secondary hover:bg-gp-bg-subtle',
  outline: 'border border-gp-border text-gp-text hover:bg-gp-bg-subtle',
};

const sizeStyles: Record<ButtonSize, string> = {
  sm: 'px-4 py-2 text-[13px]',
  md: 'px-5 py-3 text-sm',
  lg: 'px-6 py-3 text-sm',
};

/**
 * Pill-shaped button with primary/secondary/ghost/outline variants.
 * All buttons use rounded-full (pill shape) matching the prototype.
 */
export function Button({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  iconLeft,
  iconRight,
  className,
  disabled,
  ...props
}: ButtonProps) {
  return (
    <button
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-colors',
        variantStyles[variant],
        sizeStyles[size],
        fullWidth && 'w-full',
        disabled && 'opacity-50 cursor-not-allowed',
        className,
      )}
      disabled={disabled}
      {...props}
    >
      {iconLeft}
      {children}
      {iconRight}
    </button>
  );
}
