'use client';

import { type ReactNode } from 'react';
import { cn } from '../../lib/utils';

type ChoiceVariant = 'default' | 'correct' | 'incorrect' | 'dimmed';

interface ChoiceButtonProps {
  /** The letter label (A, B, C...) */
  letter: string;
  /** Choice text */
  children: ReactNode;
  /** Visual state */
  variant?: ChoiceVariant;
  /** Click handler */
  onClick?: () => void;
  /** Whether the button is disabled (after answering) */
  disabled?: boolean;
  /** Custom className */
  className?: string;
}

const variantStyles: Record<ChoiceVariant, string> = {
  default: 'bg-white border-gp-border text-gp-text hover:border-gp-blue hover:bg-[#FAFCFF] cursor-pointer',
  correct: 'bg-gp-success-light border-gp-success text-gp-text',
  incorrect: 'bg-gp-error-light border-gp-error text-gp-text',
  dimmed: 'bg-gp-bg-subtle border-gp-border-light text-gp-text-muted',
};

const badgeStyles: Record<ChoiceVariant, string> = {
  default: 'border-2 border-gp-border text-gp-text-muted',
  correct: 'bg-gp-success text-white',
  incorrect: 'bg-gp-error text-white',
  dimmed: 'border-2 border-gp-border-light text-gp-text-muted',
};

/**
 * Multiple-choice answer button with letter badge (A/B/C).
 * Supports correct/incorrect/dimmed states for quiz-style interactions.
 */
export function ChoiceButton({
  letter,
  children,
  variant = 'default',
  onClick,
  disabled = false,
  className,
}: ChoiceButtonProps) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'flex items-start gap-3 p-3.5 rounded-xl border text-left text-sm leading-relaxed transition-all font-normal',
        variantStyles[variant],
        disabled && 'cursor-default',
        className,
      )}
      aria-label={`Option ${letter}`}
    >
      <span
        className={cn(
          'w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0',
          badgeStyles[variant],
        )}
      >
        {variant === 'correct' ? (
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12" />
          </svg>
        ) : variant === 'incorrect' ? (
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        ) : (
          letter
        )}
      </span>
      <span>{children}</span>
    </button>
  );
}
