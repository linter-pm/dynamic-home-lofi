import { type ReactNode } from 'react';
import { cn } from '../../lib/utils';

type FeedbackVariant = 'success' | 'error';

interface FeedbackBoxProps {
  /** Success or error state */
  variant: FeedbackVariant;
  /** Heading text */
  heading: string;
  /** Body content */
  children: ReactNode;
  /** Optional icon override — defaults to circled check/X */
  icon?: ReactNode;
  /** Custom className */
  className?: string;
}

const variantStyles: Record<FeedbackVariant, { container: string; heading: string }> = {
  success: {
    container: 'bg-gp-success-light border-gp-success-border',
    heading: 'text-gp-success',
  },
  error: {
    container: 'bg-gp-error-light border-gp-error-border',
    heading: 'text-gp-error',
  },
};

/**
 * Success/error feedback panel with icon, heading, and detail text.
 * Slides up on mount using animate-slide-up. Used for quiz answers, form validation.
 */
export function FeedbackBox({
  variant,
  heading,
  children,
  icon,
  className,
}: FeedbackBoxProps) {
  const styles = variantStyles[variant];

  const defaultIcon = variant === 'success' ? (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  ) : (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <line x1="15" y1="9" x2="9" y2="15" />
      <line x1="9" y1="9" x2="15" y2="15" />
    </svg>
  );

  return (
    <div
      className={cn(
        'rounded-xl p-4 border animate-slide-up',
        styles.container,
        className,
      )}
    >
      <div className={cn('flex items-center gap-2 mb-1.5 text-sm font-semibold', styles.heading)}>
        {icon ?? defaultIcon}
        {heading}
      </div>
      <div className="text-sm leading-relaxed text-gp-text">
        {children}
      </div>
    </div>
  );
}
