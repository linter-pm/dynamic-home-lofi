'use client';

import { cn } from '../../lib/utils';

interface SetupOptionProps {
  /** Option label text */
  label: string;
  /** Whether this option is currently selected */
  selected: boolean;
  /** Click handler */
  onClick: () => void;
  /** Custom className */
  className?: string;
}

/**
 * Radio-button-style selection card with custom radio circle indicator.
 * Used for single-select option lists (role picker, experience level, etc.).
 */
export function SetupOption({
  label,
  selected,
  onClick,
  className,
}: SetupOptionProps) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'flex items-center gap-3 px-4 py-3.5 rounded-xl border text-left text-sm transition-all w-full',
        selected
          ? 'border-gp-blue bg-gp-blue-light'
          : 'border-gp-border bg-white hover:border-gp-blue hover:bg-[#FAFCFF]',
        className,
      )}
      role="radio"
      aria-checked={selected}
    >
      <div
        className={cn(
          'w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all',
          selected ? 'border-gp-blue bg-gp-blue' : 'border-gp-border',
        )}
      >
        {selected && <div className="w-2 h-2 rounded-full bg-white" />}
      </div>
      <span className="font-medium">{label}</span>
    </button>
  );
}
