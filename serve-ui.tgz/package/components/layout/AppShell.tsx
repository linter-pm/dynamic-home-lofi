'use client';

import { useState, type ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface Breadcrumb {
  label: string;
  href?: string;
}

interface AppShellProps {
  /** Page content */
  children: ReactNode;
  /** Breadcrumb trail. Last item renders as active (bold, no link). */
  breadcrumbs?: Breadcrumb[];
  /** Sidebar content — pass your own Sidebar component */
  sidebar?: ReactNode;
  /** Custom className for the outer wrapper */
  className?: string;
  /**
   * Render function for breadcrumb links.
   * Needed because the library is framework-agnostic (Next.js Link, React Router, etc.)
   * Falls back to <a> if not provided.
   */
  renderLink?: (props: { href: string; children: ReactNode; className?: string }) => ReactNode;
}

/**
 * Top-level app layout: sidebar + header bar with breadcrumbs + scrollable content area.
 * Pass your own sidebar component and link renderer for framework compatibility.
 */
export function AppShell({
  children,
  breadcrumbs = [],
  sidebar,
  className,
  renderLink,
}: AppShellProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const Link = renderLink ?? (({ href, children: c, className: cls }) => (
    <a href={href} className={cls}>{c}</a>
  ));

  return (
    <div className={cn('flex min-h-screen', className)}>
      {/* Desktop sidebar */}
      {sidebar && (
        <aside className="hidden lg:block flex-shrink-0 h-screen sticky top-0">
          {sidebar}
        </aside>
      )}

      {/* Mobile sidebar overlay */}
      {sidebar && mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/30"
            onClick={() => setMobileOpen(false)}
          />
          <div className="relative z-10 h-full">
            {sidebar}
          </div>
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Top bar */}
        <header className="h-12 border-b border-gp-border-light flex items-center px-4 lg:px-6 flex-shrink-0 bg-white">
          {sidebar && (
            <button
              className="lg:hidden flex items-center justify-center w-9 h-9 rounded-md hover:bg-black/[0.04] mr-2"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation menu"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="3" y1="12" x2="21" y2="12" />
                <line x1="3" y1="6" x2="21" y2="6" />
                <line x1="3" y1="18" x2="21" y2="18" />
              </svg>
            </button>
          )}

          <nav className="flex items-center text-sm" aria-label="Breadcrumb">
            {breadcrumbs.length === 0 ? (
              <span className="font-medium text-gp-text">Dashboard</span>
            ) : (
              breadcrumbs.map((crumb, i) => (
                <span key={i} className="flex items-center">
                  {i > 0 && (
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="mx-1.5 text-gp-text-secondary">
                      <polyline points="9 18 15 12 9 6" />
                    </svg>
                  )}
                  {crumb.href ? (
                    <Link
                      href={crumb.href}
                      className="text-gp-text-secondary hover:text-gp-text transition-colors"
                    >
                      {crumb.label}
                    </Link>
                  ) : i === breadcrumbs.length - 1 ? (
                    <span className="font-medium text-gp-text">{crumb.label}</span>
                  ) : (
                    <span className="text-gp-text-secondary">{crumb.label}</span>
                  )}
                </span>
              ))
            )}
          </nav>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto scroll-area">
          {children}
        </main>
      </div>
    </div>
  );
}
