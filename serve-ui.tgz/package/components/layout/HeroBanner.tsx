import { type ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface HeroBannerProps {
  /** Heading text */
  title: string;
  /** Supporting description */
  subtitle?: string;
  /** Small text above the title */
  eyebrow?: string;
  /** Additional content below subtitle */
  children?: ReactNode;
  /** Custom className */
  className?: string;
}

/**
 * Navy-gradient hero banner for page headers.
 * Gradient goes from midnight-900 to a deep blue.
 */
export function HeroBanner({
  title,
  subtitle,
  eyebrow,
  children,
  className,
}: HeroBannerProps) {
  return (
    <div
      className={cn(
        'bg-gradient-to-br from-[#0B1529] to-[#1E3A5F] text-white rounded-card p-6 lg:p-7 relative overflow-hidden',
        className,
      )}
    >
      {/* Decorative circle */}
      <div className="absolute -top-8 -right-8 w-36 h-36 bg-white/[0.04] rounded-full" />

      {eyebrow && (
        <p className="text-[13px] text-white/60 mb-1.5">{eyebrow}</p>
      )}
      <h1 className="font-outfit text-xl font-semibold leading-tight mb-2">
        {title}
      </h1>
      {subtitle && (
        <p className="text-sm text-white/65 leading-relaxed">{subtitle}</p>
      )}
      {children}
    </div>
  );
}
