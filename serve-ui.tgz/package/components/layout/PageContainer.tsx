import { type ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface PageContainerProps {
  children: ReactNode;
  /** Max width — defaults to 720px (content pages) */
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl';
  /** Custom className */
  className?: string;
}

const maxWidthMap = {
  sm: 'max-w-[520px]',
  md: 'max-w-[720px]',
  lg: 'max-w-[960px]',
  xl: 'max-w-[1100px]',
} as const;

/**
 * Centered content wrapper with responsive horizontal padding.
 * Use inside AppShell's main content area for consistent page layouts.
 */
export function PageContainer({
  children,
  maxWidth = 'md',
  className,
}: PageContainerProps) {
  return (
    <div className={cn(maxWidthMap[maxWidth], 'mx-auto px-4 lg:px-8 py-6', className)}>
      {children}
    </div>
  );
}
