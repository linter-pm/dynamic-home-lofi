'use client';

import { type ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface NavItem {
  label: string;
  href: string;
  active?: boolean;
}

interface SidebarProps {
  /** Brand label — small text above title (e.g., "GoodParty.org") */
  brandLabel?: string;
  /** Brand title — role or product name (e.g., "City Council Member") */
  brandTitle?: string;
  /** Navigation items — text only, no icons (matches Lovable prototype) */
  navItems?: NavItem[];
  /** Footer content (user info) */
  footer?: ReactNode;
  /** Custom className */
  className?: string;
  /** Callback when a nav item is clicked */
  onNavClick?: (href: string) => void;
  /**
   * Render function for nav links.
   * Falls back to <button> if not provided.
   */
  renderLink?: (props: { href: string; children: ReactNode; className?: string; onClick?: () => void }) => ReactNode;
}

/**
 * Sidebar matching the Lovable prototype exactly:
 * - White/light background (#fafafa)
 * - Text-only nav items (no icons)
 * - Brand area with label + title (not bolded label)
 * - User profile footer with avatar
 */
export function Sidebar({
  brandLabel = 'GoodParty.org',
  brandTitle,
  navItems = [],
  footer,
  className,
  onNavClick,
  renderLink,
}: SidebarProps) {
  return (
    <div className={cn('flex flex-col h-full w-64 bg-[#fafafa] border-r border-[#e5e5e5]', className)}>
      {/* Brand area — label is NOT bolded */}
      <div className="px-3 pt-3 pb-1">
        <div className="px-2 py-2 rounded-md hover:bg-black/[0.04] transition-colors cursor-pointer">
          <div className="text-xs text-black/55">{brandLabel}</div>
          {brandTitle && (
            <div className="text-sm font-semibold text-[#0a0a0a]">{brandTitle}</div>
          )}
        </div>
      </div>

      {/* Nav — text only, no icons */}
      <nav className="flex-1 px-3 py-1">
        {navItems.map((item) => {
          const content = (
            <span>{item.label}</span>
          );

          if (renderLink) {
            return renderLink({
              key: item.label,
              href: item.href,
              className: cn(
                'block w-full text-left px-4 py-2.5 rounded-md text-sm mb-0.5 transition-colors',
                item.active
                  ? 'bg-black/[0.05] font-medium text-[#0a0a0a]'
                  : 'text-black/[0.65] hover:bg-black/[0.04]',
              ),
              onClick: () => onNavClick?.(item.href),
              children: content,
            } as any);
          }

          return (
            <button
              key={item.label}
              onClick={() => onNavClick?.(item.href)}
              className={cn(
                'block w-full text-left px-4 py-2.5 rounded-md text-sm mb-0.5 transition-colors',
                item.active
                  ? 'bg-black/[0.05] font-medium text-[#0a0a0a]'
                  : 'text-black/[0.65] hover:bg-black/[0.04]',
              )}
            >
              {content}
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      {footer && (
        <div className="px-3 py-3 mt-auto border-t border-[#e5e5e5]">
          {footer}
        </div>
      )}
    </div>
  );
}
