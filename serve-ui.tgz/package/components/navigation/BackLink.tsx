import { type ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface BackLinkProps {
  /** Link text */
  children: ReactNode;
  /** Destination URL */
  href: string;
  /** Custom className */
  className?: string;
  /** Render function for the link */
  renderLink?: (props: { href: string; children: ReactNode; className?: string }) => ReactNode;
}

/**
 * Back navigation link with left chevron icon.
 * Used at the top of sub-pages to return to parent.
 */
export function BackLink({
  children,
  href,
  className,
  renderLink,
}: BackLinkProps) {
  const Link = renderLink ?? (({ href: h, children: c, className: cls }) => (
    <a href={h} className={cls}>{c}</a>
  ));

  return (
    <Link
      href={href}
      className={cn(
        'inline-flex items-center gap-1 text-sm text-gp-text-secondary hover:text-gp-text mb-3 py-2',
        className,
      )}
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="15 18 9 12 15 6" />
      </svg>
      {children}
    </Link>
  );
}
