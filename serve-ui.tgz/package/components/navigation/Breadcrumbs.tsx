import { type ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface BreadcrumbsProps {
  /** Breadcrumb trail items */
  items: BreadcrumbItem[];
  /** Custom className */
  className?: string;
  /** Render function for links */
  renderLink?: (props: { href: string; children: ReactNode; className?: string }) => ReactNode;
}

/**
 * Standalone breadcrumb trail with chevron separators.
 * For use outside of AppShell when you need breadcrumbs in custom layouts.
 */
export function Breadcrumbs({ items, className, renderLink }: BreadcrumbsProps) {
  const Link = renderLink ?? (({ href, children, className: cls }) => (
    <a href={href} className={cls}>{children}</a>
  ));

  return (
    <nav className={cn('flex items-center text-sm', className)} aria-label="Breadcrumb">
      {items.map((item, i) => (
        <span key={i} className="flex items-center">
          {i > 0 && (
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="mx-1.5 text-gp-text-secondary">
              <polyline points="9 18 15 12 9 6" />
            </svg>
          )}
          {item.href ? (
            <Link
              href={item.href}
              className="text-gp-text-secondary hover:text-gp-text transition-colors"
            >
              {item.label}
            </Link>
          ) : i === items.length - 1 ? (
            <span className="font-medium text-gp-text">{item.label}</span>
          ) : (
            <span className="text-gp-text-secondary">{item.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}
