import { cn } from '../../lib/utils';

interface ProgressBarProps {
  /** Progress percentage (0-100) */
  value: number;
  /** Custom className */
  className?: string;
}

/**
 * Linear progress bar with blue fill.
 * Uses gp-border-light track and gp-blue fill.
 */
export function ProgressBar({ value, className }: ProgressBarProps) {
  const clamped = Math.min(100, Math.max(0, value));

  return (
    <div
      className={cn('bg-gp-border-light rounded-full h-1.5 overflow-hidden', className)}
      role="progressbar"
      aria-valuenow={clamped}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className="bg-gp-blue h-full rounded-full transition-all duration-300"
        style={{ width: `${clamped}%` }}
      />
    </div>
  );
}
