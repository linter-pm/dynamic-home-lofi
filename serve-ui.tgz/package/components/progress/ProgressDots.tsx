'use client';

import { cn } from '../../lib/utils';

interface ProgressDotsProps {
  /** Total number of steps */
  total: number;
  /** Current step index (0-based) */
  current: number;
  /** Custom className */
  className?: string;
}

/**
 * Dot-based step indicator. Active dot is wide (w-6), past dots are faded,
 * future dots are gray. Used for multi-step flows.
 */
export function ProgressDots({ total, current, className }: ProgressDotsProps) {
  return (
    <div
      className={cn('flex gap-1.5 justify-center py-3', className)}
      role="progressbar"
      aria-valuenow={current + 1}
      aria-valuemin={1}
      aria-valuemax={total}
    >
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          className={cn(
            'h-1.5 rounded-full transition-all duration-300',
            i === current
              ? 'w-6 bg-gp-blue'
              : i < current
              ? 'w-1.5 bg-gp-blue/35'
              : 'w-1.5 bg-gp-border',
          )}
        />
      ))}
    </div>
  );
}
