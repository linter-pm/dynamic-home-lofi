import { cn } from '../../lib/utils';

interface StepIndicatorProps {
  /** Total number of steps */
  total: number;
  /** Current step (1-based) */
  current: number;
  /** Custom className */
  className?: string;
}

/**
 * Horizontal pip bars for multi-step flows.
 * Each step is a thin bar; completed bars are blue, current is blue, future is gray.
 */
export function StepIndicator({ total, current, className }: StepIndicatorProps) {
  return (
    <div
      className={cn('flex gap-1', className)}
      role="progressbar"
      aria-valuenow={current}
      aria-valuemin={1}
      aria-valuemax={total}
    >
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          className={cn(
            'h-1 flex-1 rounded-full transition-all duration-300',
            i < current ? 'bg-gp-blue' : 'bg-gp-border-light',
          )}
        />
      ))}
    </div>
  );
}
