/** GoodParty Serve color tokens — extracted from the Lovable prototype */

export const colors = {
  /** Primary interactive blue — CTAs, links, active states */
  primary: '#2563EB',
  /** Blue hover state */
  primaryHover: '#0D3CB5',
  /** Navy — hero banners, dark gradient sections (NOT sidebar) */
  navy: '#0B1529',
  /** Navy 800 — slightly lighter navy */
  navy800: '#14234D',

  /** Sidebar background — white/light gray per Lovable prototype */
  sidebar: '#fafafa',
  /** Sidebar border */
  sidebarBorder: '#e5e5e5',
  /** Sidebar text — dark on light */
  sidebarText: 'rgba(10,10,10,0.65)',
  /** Sidebar active item background */
  sidebarActive: 'rgba(0,0,0,0.05)',
  /** Sidebar active text */
  sidebarActiveText: '#0a0a0a',

  /** Primary text color */
  text: '#1E1F20',
  /** Secondary text — supporting copy, labels */
  textSecondary: '#70757A',
  /** Tertiary/muted text — timestamps, hints */
  textMuted: '#879099',

  /** Light background — subtle sections */
  bgSubtle: '#F7FAFB',
  /** Default background */
  bg: '#FFFFFF',
  /** Default border */
  border: '#D1D8DF',
  /** Light border — dividers, subtle separators */
  borderLight: '#E0E6EC',

  /** Success green */
  success: '#059669',
  /** Success light background */
  successLight: '#ECFDF5',
  /** Success border */
  successBorder: '#A7F3D0',

  /** Error red */
  error: '#E00C30',
  /** Error light background */
  errorLight: '#FEF2F2',
  /** Error border */
  errorBorder: '#FECACA',

  /** Warning amber */
  warning: '#D97706',
  /** Warning light background */
  warningLight: '#FFFBEB',
  /** Warning border */
  warningBorder: '#FDE68A',

  /** Blue light background */
  blueLight: '#EFF6FF',
  /** Blue 50 — softer blue bg */
  blue50: '#DBEAFE',
  /** Blue border */
  blueBorder: '#BFDBFE',
} as const;

export type ColorToken = keyof typeof colors;
