/** GoodParty Serve spacing scale (px values) */

export const spacing = {
  1: '4px',
  1.5: '6px',
  2: '8px',
  2.5: '10px',
  3: '12px',
  3.5: '14px',
  4: '16px',
  5: '20px',
  6: '24px',
  7: '28px',
  8: '32px',
  10: '40px',
} as const;

export const borderRadius = {
  /** Small buttons, tags */
  sm: '6px',
  /** Inputs */
  md: '8px',
  /** Medium containers */
  DEFAULT: '10px',
  /** Cards, standard containers */
  lg: '12px',
  /** Large cards, hero sections */
  xl: '16px',
  /** Pills, badges, round buttons */
  full: '9999px',
} as const;

export const boxShadow = {
  /** Subtle card shadow */
  subtle: '0 2px 8px rgba(0,0,0,0.06)',
  /** Card hover with blue tint */
  cardHover: '0 4px 12px rgba(37,99,235,0.08)',
} as const;

export const transition = {
  /** Standard interaction transition */
  standard: 'all 0.15s',
  /** Animation duration for slide/fade */
  animation: '0.3s',
} as const;
