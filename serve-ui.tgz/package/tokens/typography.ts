/** GoodParty Serve typography tokens */

export const fontFamily = {
  /** Body text — Inter with system fallbacks */
  sans: 'Inter, system-ui, -apple-system, sans-serif',
  /** Heading text — Outfit for display/heading hierarchy */
  heading: 'Outfit, system-ui, sans-serif',
  /** Body text alternative — Open Sans for longer reads */
  body: '"Open Sans", system-ui, -apple-system, sans-serif',
} as const;

export const fontSize = {
  '2xs': '11px',
  xs: '12px',
  sm: '13px',
  base: '14px',
  md: '15px',
  lg: '16px',
  xl: '18px',
  '2xl': '20px',
  '3xl': '22px',
} as const;

export const fontWeight = {
  normal: '400',
  medium: '500',
  semibold: '600',
  bold: '700',
} as const;

export const letterSpacing = {
  /** Uppercase labels tracking */
  wide: '0.05em',
} as const;

export type FontSizeToken = keyof typeof fontSize;
export type FontWeightToken = keyof typeof fontWeight;
